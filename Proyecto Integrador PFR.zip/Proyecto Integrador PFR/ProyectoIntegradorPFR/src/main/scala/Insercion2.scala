package ec.edu.utpl.presencial.computacion.pfr.pintegra

import com.github.tototoshi.csv._
import java.io.File
import doobie._
import doobie.implicits._
import cats._
import cats.effect._
import cats.effect.unsafe.implicits.global

implicit object CustomFormat extends DefaultCSVFormat {
  override val delimiter: Char = ';'
}

object Insercion2 {

  @main
  def PartidosyGoles(): Unit = {
    val path2DataFile: String = "C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador William y Lenin\\PartidosYGolesLimpia.csv"
    val reader = CSVReader.open(new File(path2DataFile))
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()
    val xa = Transactor.fromDriverManager[IO](
      driver = "com.mysql.cj.jdbc.Driver",
      url = "jdbc:mysql://localhost:3306/ProyectoIntegrador",
      user = "root",
      password = "lenin123",
      logHandler = None
    )

    //val tournamentUpdates: List[Update0] = dataForTournaments(contentFile)
    //tournamentUpdates.foreach(update => update.run.transact(xa).unsafeRunSync())

    //val stadiumUpdates: List[Update0] = dataForStadium(contentFile)
    //stadiumUpdates.foreach(update => update.run.transact(xa).unsafeRunSync())

    //val matchUpdates: List[Update0] = dataForMatches(contentFile)
    //matchUpdates.foreach(update => update.run.transact(xa).unsafeRunSync())

    //val HometeamsUpdates: List[Update0] = dataForHometeams(contentFile)
    //HometeamsUpdates.foreach(update => update.run.transact(xa).unsafeRunSync())

    val AwayteamsUpdates: List[Update0] = dataForAwayteams(contentFile)
    AwayteamsUpdates.foreach(update => update.run.transact(xa).unsafeRunSync())

    //val GoalsUpdates: List[Update0] = dataForGoals(contentFile)
    //GoalsUpdates.foreach(update => update.run.transact(xa).unsafeRunSync())
  }

  //TOURNAMENTS
  def dataForTournaments(data: List[Map[String, String]]): List[Update0] =
    data.distinctBy(_("matches_tournament_id"))
      .map(row =>
        (
          row("matches_tournament_id"),
          row("tournaments_tournament_name"),
          row("tournaments_year"),
          row("tournaments_host_country"),
          row("tournaments_winner"),
          row("tournaments_count_teams")
        )
      )
      .map { utp =>
        sql"""INSERT INTO tournaments (matches_tournament_id, tournaments_tournament_name,
                         tournaments_year, tournaments_host_country,
                         tournaments_winner, tournaments_count_teams)
                VALUES (${utp._1}, ${utp._2}, ${utp._3}, ${utp._4}, ${utp._5}, ${utp._6});""".update
      }

  // STADIUM
  def dataForStadium(data: List[Map[String, String]]): List[Update0] =
    data.distinctBy(_("matches_stadium_id"))
      .map(row =>
        (
          row("matches_stadium_id"),
          row("stadiums_stadium_name"),
          row("stadiums_city_name"),
          row("stadiums_country_name"),
          row("stadiums_stadium_capacity").toInt
        )
      )
      .map { utp =>
        sql"""INSERT INTO stadiums (stadium_id, stadium_name, city_name, country_name, stadium_capacity)
              VALUES (${utp._1}, ${utp._2}, ${utp._3}, ${utp._4}, ${utp._5});""".update
      }

  // MATCHES
  def dataForMatches(data: List[Map[String, String]]): List[Update0] =
    data.distinctBy(_("matches_match_id"))
      .map(row =>
        (
          row("matches_tournament_id"),
          row("matches_match_id"),
          row("matches_away_team_id"),
          row("matches_home_team_id"),
          row("matches_stadium_id"),
          row("matches_match_date"),
          row("matches_match_time"),
          row("matches_stage_name"),
          row("matches_home_team_score").toInt,
          row("matches_away_team_score").toInt,
          row("matches_extra_time").toInt,
          row("matches_penalty_shootout").toInt,
          row("matches_home_team_score_penalties").toInt,
          row("matches_away_team_score_penalties").toInt,
          row("matches_result")
        )
      )
      .map { utp =>
        sql"""INSERT INTO matches (matches_tournament_id, matches_match_id, matches_away_team_id,
                 matches_home_team_id, matches_stadium_id, matches_match_date,
                 matches_match_time, matches_stage_name, matches_home_team_score,
                 matches_away_team_score, matches_extra_time, matches_penalty_shootout,
                 matches_home_team_score_penalties, matches_away_team_score_penalties,
                 matches_result)
              VALUES (${utp._1}, ${utp._2}, ${utp._3}, ${utp._4}, ${utp._5}, ${utp._6}, ${utp._7}, ${utp._8}, ${utp._9}, ${utp._10}, ${utp._11}, ${utp._12}, ${utp._13}, ${utp._14}, ${utp._15});""".update
      }

  // HOME TEAMS
  def dataForHometeams(data: List[Map[String, String]]): List[Update0] =
    data.distinctBy(_("matches_home_team_id"))
      .map(row =>
        (
          row("matches_home_team_id"),
          row("home_team_name"),
          row("home_region_name"),
          row("home_mens_team"),
          row("home_womens_team")
        )
      )
      .map { utp =>
        sql"""INSERT INTO home_teams (matches_home_team_id, home_team_name, home_region_name, home_mens_team, home_womens_team)
              VALUES (${utp._1}, ${utp._2}, ${utp._3}, ${utp._4}, ${utp._5});""".update
      }

  // AWAY TEAMS
  def dataForAwayteams(data: List[Map[String, String]]): List[Update0] =
    data.distinctBy(_("matches_away_team_id"))
      .map(row =>
        (
          row("matches_away_team_id"),
          row("away_team_name"),
          row("away_region_name"),
          row("away_mens_team"),
          row("away_womens_team")
        )
      )
      .map { utp =>
        sql"""INSERT INTO away_teams (matches_away_team_id, away_team_name, away_region_name, away_mens_team, away_womens_team)
              VALUES (${utp._1}, ${utp._2}, ${utp._3}, ${utp._4}, ${utp._5});""".update
      }

  // GOALS
  def dataForGoals(data: List[Map[String, String]]): List[Update0] =
    data.distinctBy(_("goals_goal_id"))
      .map(row =>
        (
          row("goals_goal_id"),
          row("goals_team_id"),
          row("goals_player_id"),
          row("goals_player_team_id"),
          row("goals_minute_label"),
          row("goals_minute_regulation"),
          row("goals_minute_stoppage"),
          row("goals_match_period"),
          row("goals_own_goal"),
          row("goals_penalty")
        )
      )
      .map { utp =>
        sql"""INSERT INTO goals (goals_goal_id, goals_team_id, goals_player_id, goals_player_team_id,
          goals_minute_label, goals_minute_regulation, goals_minute_stoppage, goals_match_period,
          goals_own_goal, goals_penalty)
          VALUES (${utp._1}, ${utp._2}, ${utp._3}, ${utp._4}, ${utp._5}, ${utp._6}, ${utp._7}, ${utp._8}, ${utp._9}, ${utp._10});""".update
      }
}
