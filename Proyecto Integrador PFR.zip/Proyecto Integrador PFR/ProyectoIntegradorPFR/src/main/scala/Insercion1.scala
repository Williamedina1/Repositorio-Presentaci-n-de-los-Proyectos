package ec.edu.utpl.presencial.computacion.pfr.pintegra

import com.github.tototoshi.csv._
import java.io.File
import doobie._
import doobie.implicits._
import cats._
import cats.effect._
import cats.effect.unsafe.implicits.global

implicit object CustomFormat extends DefaultCSVFormat {
  override val delimiter: Char = ';'
}

object Insercion1 {

  
  def AlineacionesXTorneo() =
    val path2DataFile: String = "C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador William y Lenin\\AlineacionesXTorneoLimpia.csv"
    val reader = CSVReader.open(new File(path2DataFile))
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()
    generateData2Players(contentFile)
    //generateData2Squads(contentFile)

    // PLAYERS
    def generateData2Players(data: List[Map[String, String]]): Unit = {
      val sqlInsert = s"INSERT INTO players (squads_player_id, players_family_name, players_given_name, players_birth_date,players_female,players_goal_keeper,players_defender,players_midfielder,players_forward)" +
        s"VALUES('%s','%s','%s','%s', %d, %d, %d, %d, %d);"

      val playersTuple = data.distinctBy(_("squads_player_id"))
        .map(
          row => (
            row("squads_player_id"),
            row("players_family_name").replaceAll("'", "\\\\'"),
            row("players_given_name").replaceAll("'", "\\\\'"),
            row("players_birth_date"),
            row("players_female").toInt,
            row("players_goal_keeper").toInt,
            row("players_defender").toInt,
            row("players_midfielder").toInt,
            row("players_forward").toInt
          )
        )
        .sortBy(_._1)
        .map(name => sqlInsert.format(name._1, name._2, name._3, name._4, name._5, name._6, name._7, name._8, name._9))
      playersTuple.foreach(println)

    }



    // SQUADS
    def generateData2Squads(data: List[Map[String, String]]): Unit = {
      val sqlInsert = s"INSERT INTO squads (squads_tournament_id, squads_player_id, squads_team_id, squads_shirt_number,squads_position_name)" +
        s"VALUES('%s','%s','%s',%d, '%s');"

      val squadsTuple = data.distinctBy(_("squads_tournament_id"))
          .map(
            row => (row("squads_tournament_id"),
              row("squads_player_id"),
              row("squads_team_id"),
              row("squads_shirt_number").toInt,
              row("squads_position_name"),
            ))
          .sortBy(_._1)
          .map(name => sqlInsert.format(name._1, name._2, name._3, name._4, name._5))

        squadsTuple.foreach(println)

    }
}