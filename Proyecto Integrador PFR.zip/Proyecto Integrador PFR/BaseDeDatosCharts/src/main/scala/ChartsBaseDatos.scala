package ec.edu.utpl.presencial.computacion.pfr.pintegra

import com.github.tototoshi.csv._
import java.io.File

import doobie._
import doobie.implicits._

import cats._
import cats.effect._
import cats.effect.unsafe.implicits.global
import cats.implicits._

import org.nspl._
import org.nspl.awtrenderer._
import org.nspl.data.HistogramData



implicit object CustomFormat extends DefaultCSVFormat {
  override val delimiter: Char = ';'
}

object ChartsBaseDatos {

  @main
  def demo(): Unit = {
    println("Charts")
    Chart1()
    Chart2()
    Chart3()

  }

  val xa = Transactor.fromDriverManager[IO](
    driver = "com.mysql.cj.jdbc.Driver",
    url = "jdbc:mysql://localhost:3306/ProyectoIntegrador",
    user = "root",
    password = "lenin123",
    logHandler = None
  )

  def Chart1(): Unit = {
    val query = sql"""
        SELECT goals_minute_regulation, COUNT(*)
        FROM goals
        WHERE goals_minute_regulation IS NOT NULL
        GROUP BY goals_minute_regulation
      """.query[(Int, Int)]

    val datos = query.to[List].transact(xa).unsafeRunSync()

    val dataSource = datos.map { case (minuto, cantidad) => minuto.toDouble -> cantidad.toDouble }
    val chart = xyplot(dataSource -> bar())(
      par
        .xlab("Minuto")
        .ylab("Cantidad de Goles")
        .main("Goles por Minuto")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador PFR\\Chart1.png"), chart.build, width = 1000)
  }

  def Chart2(): Unit = {
    val query = sql"""
      SELECT players_female, COUNT(*)
      FROM players
      WHERE players_female IS NOT NULL
      GROUP BY players_female
    """.query[(Int, Int)]

    val datos = query.to[List].transact(xa).unsafeRunSync()

    val dataSource = datos.map { case (genero, cantidad) => genero.toDouble -> cantidad.toDouble }
    val chart = xyplot(dataSource -> bar())(
      par
        .xlab("Género (1: Femenino, 0: Masculino)")
        .ylab("Cantidad de Jugadores")
        .main("Distribución de Jugadores por Género")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador PFR\\Chart2.png"), chart.build, width = 1000)
  }

  def Chart3(): Unit = {
    val query = sql"""
        SELECT squads_shirt_number
        FROM squads
        WHERE squads_position_name = 'Defender'
      """.query[Int]

    val shirtNumbers = query.to[List].transact(xa).unsafeRunSync()

    val shirtNumbersDouble: Seq[Double] = shirtNumbers.map(_.toDouble)

    val histogramData = HistogramData(shirtNumbersDouble, 20)

    val chart = xyplot(histogramData -> bar())(
      par
        .xlab("Número de Camiseta")
        .ylab("Frecuencia")
        .main("Distribución de Números de Camiseta de Defensores")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador PFR\\Chart3.png"), chart.build, width = 1000)
  }

}
