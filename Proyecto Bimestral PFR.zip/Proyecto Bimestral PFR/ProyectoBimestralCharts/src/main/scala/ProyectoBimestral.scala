package ec.edu.utpl.presencial.computacion.pfr.pintegra

import com.github.tototoshi.csv._
import java.io.File
import org.nspl._
import org.nspl.awtrenderer._
import org.nspl.data.HistogramData

implicit object CustomFormat extends DefaultCSVFormat {
  override val delimiter: Char = ';'}

object ProyectoBimestral {


  @main
  def AlineacionesXTorneo(): Unit = {
    val path2DataFile: String = "C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador William y Lenin\\AlineacionesXTorneoLimpia.csv"
    val reader = CSVReader.open(new File(path2DataFile))
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()
    charting1(contentFile)
  }

  def charting1(data: List[Map[String, String]]): Unit = {

    // Chart1 AlineacionesXTorneo
    val listNroShirtMidfielder: List[Double] = data
      .filter(row => row.contains("squads_position_name") && row("squads_position_name") == "midfielder" && row.contains("squads_shirt_number") && row("squads_shirt_number") != "0")
      .map(row => row("squads_shirt_number").toDouble)

    val histMidfielderShirtNumber = xyplot(HistogramData(listNroShirtMidfielder, 20) -> line())(
      par
        .xlab("Shirt number")
        .ylab("freq.")
        .main("Midfielder shirt number")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Bimestral PFR\\Chart1AlineacionesXTorneo.png"),
      histMidfielderShirtNumber.build, width = 1000)

    // Chart2 AlineacionesXTorneo
    val listNroShirtDefender: List[Double] = data
      .filter(row => row.contains("squads_position_name") && row("squads_position_name") == "defender" && row.contains("squads_shirt_number") && row("squads_shirt_number") != "0")
      .map(row => row("squads_shirt_number").toDouble)

    val histDefenderShirtNumber = xyplot(HistogramData(listNroShirtDefender, 20) -> line())(
      par

        .xlab("Shirt number")
        .ylab("freq.")
        .main("Defender shirt number")

    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Bimestral PFR\\Chart2AlineacionesXTorneo.png"),
      histDefenderShirtNumber.build, width = 1000)

    // Chart3 AlineacionesXTorneo
    val listNroShirtGoalkeeper: List[Double] = data
      .filter(row => row.contains("squads_position_name") && row("squads_position_name") == "goal keeper" && row.contains("squads_shirt_number") && row("squads_shirt_number") != "0")
      .map(row => row("squads_shirt_number").toDouble)

    val histGoalkeeperShirtNumber = xyplot(HistogramData(listNroShirtGoalkeeper, 20) -> bar())(
      par
        .xlab("Shirt number")
        .ylab("freq.")
        .main("Goalkeeper shirt number")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Bimestral PFR\\Chart3AlineacionesXTorneo.png"),
      histGoalkeeperShirtNumber.build, width = 1000)


  }


/*
  def PartidosyGoles() =
    val path2DataFile: String = "C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador William y Lenin\\PartidosYGolesLimpia.csv"
    val reader = CSVReader.open(new File(path2DataFile))
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()
  //println(contentFile)
    charting2(contentFile)

  def charting2(data: List[Map[String, String]]): Unit = {

    // Chart1 PartidosYGoles
    val listHomeTeamScores: List[Double] = data
      .filter(row => row.contains("matches_home_team_score"))
      .map(row => row("matches_home_team_score").toDouble)

    val histHomeTeamScores = xyplot(HistogramData(listHomeTeamScores, 20) -> bar())(
      par
        .xlab("home team score")
        .ylab("freq.")
        .main("Histograma home team score")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Bimestral PFR\\Chart1PartidosYGoles.png"),
      histHomeTeamScores.build, width = 1000)

    // Chart2 PartidosYGoles
    val listAwayTeamScores: List[Double] = data
      .filter(row => row.contains("matches_away_team_score"))
      .map(row => row("matches_away_team_score").toDouble)

    val histAwayTeamScores = xyplot(HistogramData(listAwayTeamScores, 20) -> line())(
      par
        .xlab("away team score")
        .ylab("freq.")
        .main("Histograma away team score")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Bimestral PFR\\Chart2PartidosYGoles.png"),
      histAwayTeamScores.build, width = 1000)

    // Chart3 PartidosYGoles
    val listStadiumCapacities: List[Double] = data
      .filter(row => row.contains("stadiums_stadium_capacity"))
      .map(row => row("stadiums_stadium_capacity").toDouble)

    val histStadiumCapacities = xyplot(HistogramData(listStadiumCapacities, 20) -> bar())(
      par
        .xlab("Stadium capacity")
        .ylab("freq.")
        .main("Histograma Stadium capacity")
    )

    pngToFile(new File("C:\\Users\\Usuario iTC\\Desktop\\Proyecto Bimestral PFR\\Chart3PartidosYGoles.png"),
      histStadiumCapacities.build, width = 1000)
  }*/
}