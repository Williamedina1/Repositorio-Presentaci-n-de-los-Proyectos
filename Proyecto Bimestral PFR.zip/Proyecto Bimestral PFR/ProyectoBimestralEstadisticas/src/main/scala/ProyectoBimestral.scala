package ec.edu.utpl.presencial.computacion.pfr.pintegra

import com.github.tototoshi.csv.*

import java.io.File

import org.nspl.*
import org.nspl.awtrenderer.*
import org.nspl.data.HistogramData

implicit object CustomFormat extends DefaultCSVFormat {
  override val delimiter: Char = ';'
}

object ProyectoBimestral {

  /*@main
  def PartidosyGoles() =
    val path2DataFile: String = "C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador William y Lenin\\PartidosYGolesLimpia.csv"
    val reader = CSVReader.open(new File(path2DataFile)) // Lector del archivo
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()
    //println(contentFile)

  */
  @main
  def AlineacionesXTorneo() =
    val path2DataFile: String = "C:\\Users\\Usuario iTC\\Desktop\\Proyecto Integrador William y Lenin\\AlineacionesXTorneoLimpia.csv"
    val reader = CSVReader.open(new File(path2DataFile))
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()
    //println(contentFile)


//Consultas Estadisticas de PartidosyGoles
  /*
    val homeTeamScores: List[Int] = contentFile.map(_("matches_home_team_score").toInt)

    val awayTeamScores: List[Int] = contentFile.map(_("matches_away_team_score").toInt)


    val modaHomeTeamScores: Int = moda(homeTeamScores)
    val modaAwayTeamScores: Int = moda(awayTeamScores)
    val maxHomeTeamScore: Int = homeTeamScores.max
    val maxAwayTeamScore: Int = awayTeamScores.max
    val minHomeTeamScore: Int = homeTeamScores.min
    val minAwayTeamScore: Int = awayTeamScores.min
    val promedioHomeTeamScore: Double = promedio(homeTeamScores)
    val promedioAwayTeamScore: Double = promedio(awayTeamScores)


    println(s"Moda Home Team Scores: $modaHomeTeamScores")
    println(s"Moda Away Team Scores: $modaAwayTeamScores")
    println(s"Máximo Home Team Score: $maxHomeTeamScore")
    println(s"Máximo Away Team Score: $maxAwayTeamScore")
    println(s"Mínimo Home Team Score: $minHomeTeamScore")
    println(s"Mínimo Away Team Score: $minAwayTeamScore")
    println(s"Promedio Home Team Score: $promedioHomeTeamScore")
    println(s"Promedio Away Team Score: $promedioAwayTeamScore")
  */


//Consultas Estadisticas de AlineacionesXTorneo

    val squadsShirtNumber: List[Int] = contentFile.map(_("squads_shirt_number").toInt)

    val promediosquadsShirtNumber: Double = promedio(squadsShirtNumber)
    val desviacionmediasquadsShirtNumber: Double = DesviacionMedia(squadsShirtNumber)
    val varianzasquadsShirtNumber: Double = varianza(squadsShirtNumber)

    println(s"Promedio squadsShirtNumber: $promediosquadsShirtNumber")
    println(s"Desviacion Medina squadsShirtNumber: $desviacionmediasquadsShirtNumber")
    println(s"Varianza squadsShirtNumber: $varianzasquadsShirtNumber")



}

// Función para calcular la Moda
def moda(datos: List[Int]): Int = datos.groupBy(identity).mapValues(_.size).maxBy(_._2)._1

// Función para calcular el Promedio
def promedio(datos: List[Int]): Double = datos.foldLeft(0.0)(_ + _) / datos.length.toDouble

//Funcion para calcular la Desviacion Media
def DesviacionMedia(datos: List[Int]): Double =
  val n = datos.length
  val media = datos.sum.toDouble / n
  val numerador = datos.map(x => Math.abs(x - media))
  numerador.sum / n

//Funcion para calcular la Varianza
def varianza(datos: List[Int]): Double =

  val n = datos.length
  val media = datos.sum.toDouble / n
  val numerador = datos.map(x => Math.pow(x - media, 2))
  Math.sqrt(numerador.sum / n)

